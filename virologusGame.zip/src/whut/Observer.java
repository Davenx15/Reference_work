package whut;

public interface Observer {
	public void update();
}
