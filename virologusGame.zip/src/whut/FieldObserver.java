package whut;

import java.io.Serializable;

public class FieldObserver implements Observer, Serializable{
    public void update(){

    }

}
