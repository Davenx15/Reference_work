#ifndef KOSAR_H_INCLUDED
#define KOSAR_H_INCLUDED
#include "Csapat.h"
#include "memtrace.h"

class Kosar:public Csapat{
    int pompom;
public:
    Kosar(std::string str="", int n=0, int a=0):Csapat(str,n), pompom(a){}
    int getPom(){return pompom;}  //teszthez kell

    void setter(){
        setName();
        setNum();
        std::cout<<"How many CHEERLEADERS?"<<std::endl;
        std::cin>>pompom;
    }

    void print() const {
        std::cout <<"\tBASKETBALL TEAM"<<"\n\tTEAM-NAME:\t"<<nev<<
        "\n\tPLAYERS:\t"<<letszam<<"\n\tCHEERLEADERS:\t"<< pompom <<std::endl;
    }
     void printf(std::ofstream &os) const{
         os<<"1 "<<pompom<<" "<<letszam<<" -"<<nev<<std::endl;
     }

    ~Kosar(){}
};





#endif // KOSAR_H_INCLUDED
