///Az adatok.txt fájlban tárolandók csapatok.
///Mégpedig kód adat létszám név
///          ^-(1.kód a kosárcsapatot, 2.kód a focicsapatokat, 3.kód a kézilabda csapatokat)

#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#include <iostream>
#include <fstream>
#include "memtrace.h"

#include "Csapat.h"

class Lista{
    size_t db;
    Csapat **tarol;
public:

    ///Default konstruktor
    Lista():db(0),tarol(NULL){}

    int getdb(){return db;} //teszteléshez,azért int mert size_t tipust nem ismer a gtest

    ///feltölti a fájlból a listát
    void feltolt(std::ifstream& is);

    ///visszaírja a listából a fájlba az adatokat
    void visszair(std::ofstream& os) const;

    ///Listához hozzáad még egy csapatot
    ///@param hozzáadni kívánt csapatra mutató pointer
    void add(Csapat* uj);

    ///Kitörli egy felhasználó által választott csapatot
    void delete_team();

    /// képernyõre jeleníti meg az összes csapatot
    void kiir() const {
        for (size_t i = 0; i < db; i++) {
            std::cout <<i+1;
            tarol[i]->print();
            std::cout<<std::endl;
        }
    }

    ///Destrukor
    ~Lista(){
        for(size_t i=0; i<db;i++){
            delete tarol[i];
        }
        delete[] tarol;
    }
};



#endif // LISTA_H_INCLUDED
