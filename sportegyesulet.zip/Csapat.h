#ifndef CSAPAT_H_INCLUDED
#define CSAPAT_H_INCLUDED
#include "memtrace.h"

//Csapat absztrakt oszt�ly(nem hozhat� l�tre csapat an�lk�l, hogy az egy sport�ghoz tartozna)
class Csapat{
protected:
    std::string nev;
    int letszam;
public:

    ///Konstruktor
    ///@param str, csapat neve
    ///@param n, csapat l�tsz�ma
    Csapat(std::string str="", int n=0):nev(str), letszam(n){}

    int getLetszam(){return letszam;}    //tesztel�shez
    std::string getNev(){return nev;}   //tesztel�shez

    ///Tetsz�leges n�v megad�sa
    void setName(){
        std::cin.ignore();
        std::cout<<"The team name?"<<std::endl;
        getline(std::cin,nev);
    }

    ///Tetsz�leges l�tsz�m megad�sa
    void setNum(){
        std::cout<<"The team size?"<<std::endl;
        std::cin>>letszam;
    }

    ///Virtu�lis szetter
    ///A megfelel� lesz�rmazott �s �soszt�ly adatait �ll�tja be
    virtual void setter() = 0;

    ///Virtu�lis kii�r�
    ///Ki�rja a megfelel� csapat adatait a konzolra
    virtual void print() const = 0;

    ///Virtu�lis kii�r�
    ///Be�rja a megfelel� csapat adatait a f�jlba
    ///@param os, ebbe a f�jlba
    virtual void printf(std::ofstream &os) const = 0;


    ///Destruktor
    virtual ~Csapat(){}
};




#endif // CSAPAT_H_INCLUDED
