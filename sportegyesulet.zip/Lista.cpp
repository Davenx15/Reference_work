#include <string>
#include <iostream>
#include <fstream>

#include "Kosar.h"
#include "Foci.h"
#include "Kezi.h"
#include "Lista.h"


void Lista::add(Csapat *uj){

    Csapat **ujtarol;               //Csapatok pointer�t t�roljuk
    ujtarol=new Csapat*[db+1];

    for(size_t i=0; i<db; i++){     //Minden elemet �tm�solunk
        ujtarol[i]=tarol[i];
    }
    ujtarol[db]=uj;                 //Uj elem berak�sa
    delete[] tarol;                 //R�gi t�rol� t�rl�se
    tarol=ujtarol;                  //ujt�rol� az oszt�ly t�rol�j�ba
    db++;
}

 void Lista::delete_team(){
    size_t melyiket;
    std::cout<<"Which team would you REMOVE from the list?(index)"<<std::endl;
    std::cin>>melyiket;
    if (melyiket>db || melyiket<=0) throw "rossz index";    //kiv�tel dob�s ha neml�tez� elemet t�r�lne
    Csapat **ujtarol;
    ujtarol=new Csapat*[db-1];
    size_t i=0;
    for(; i<melyiket-1; i++)         //a t�rlend� elem el�tti elemig minden pointert �tm�solunk az ujt�rol�ba
        ujtarol[i]=tarol[i];
    delete tarol[i];                //t�rlend� elemre mutat� pointer kit�rl�se
    i++;
    for(; i<db; i++)                //t�rlend� elem ut�ni tagt�l a t�rol� v�g�ig m�solunk
        ujtarol[i-1]=tarol[i];
    delete[] tarol;                 //r�gi t�rol� kit�rl�se
    tarol=ujtarol;
    db--;                           //t�rl�s miatt cs�kkentj�k az elemsz�mot.
}

void Lista::visszair(std::ofstream& os) const{
    for(size_t i=0; i<db; i++){         //t�rol� �sszes elem�nek megh�vja a vissza�r� pointer�t.
        tarol[i]->printf(os);
    }
}

void Lista::feltolt(std::ifstream& is){
    int kod,sajat,letszam;
    long double penz;
    char c;
    std::string nev;

    while(!is.eof()){           //nem j� felt�tel nek�nk de bent megoldjuk.
        is>>kod;
        if(!is.eof()){                  //�jboli f�jl v�ge ellen�rz�s, mert az el�z� sor aktiv�lhatta, �gy j� lesz
            if (kod==1){                //adatok beolvas�sa                is>>sajat;
                is>>letszam;
                is>>c;
                std::getline(is,nev);
                Kosar *uj;                      //Kos�rra mutat� pointer(csak ilyet tudunk az add()-nak adni)
                uj=new Kosar;                   //pointer elhelyez�se a mem�ri�ban
                Kosar c(nev,letszam,sajat);     //Kos�r l�trehoz�sa
                *uj=c;                          //Pointer mutasson a l�trehozott koss�rra                add(uj);                        //a pointer odaad�sa
            }            if (kod==2){                        //ugyanaz mint az el�bb                is>>sajat;
                is>>letszam;
                is>>c;
                std::getline(is,nev);
                Foci *uj;
                uj=new Foci;
                Foci b(nev,letszam,sajat);
                *uj=b;
                add(uj);
            }
            if (kod==3){
                is>>penz;                   //emiatt kell 3x le�rni a beolvas�st, mivel ez m�s tipusu adattag.
                is>>letszam;
                is>>c;
                std::getline(is,nev);
                Kezi *uj;
                Kezi a(nev,letszam,penz);
                uj=new Kezi;
                *uj=a;
                add(uj);
            }        }
    }
}

