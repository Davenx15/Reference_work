#ifndef TESZT_H_INCLUDED
#define TESZT_H_INCLUDED

#include "gtest_lite.h"
#include "Kosar.h"
#include "Foci.h"
#include "Kezi.h"
#include "Lista.h"

void teszt();

#endif // TESZT_H_INCLUDED
