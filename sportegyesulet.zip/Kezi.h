#ifndef KEZI_H_INCLUDED
#define KEZI_H_INCLUDED
#include "Csapat.h"
#include "memtrace.h"


class Kezi:public Csapat{
   long double penz;
public:

    Kezi(std::string str="", int n=0,long double a=0.0):Csapat(str,n), penz(a){}
    long double getPenz(){return penz;}
    void setter(){
        setName();
        setNum();
        std::cout<<"How much SUPPORT the team get?"<<std::endl;
        std::cin>>penz;
    }

    void print() const {
        std::cout <<"\tHANDBALL TEAM"<<"\n\tTEAM-NAME:\t"<<nev<<
        "\n\tPLAYERS:\t"<<letszam<<"\n\tTEAMMONEY:\t"<< penz <<"$"<<std::endl;
    }
     void printf(std::ofstream &os) const{
         os<<"3 "<<penz<<" "<<letszam<<" -"<<nev<<std::endl;
     }
    ~Kezi(){}
};



#endif // KEZI_H_INCLUDED
