#ifndef FOCI_H_INCLUDED
#define FOCI_H_INCLUDED
#include "Csapat.h"
#include "memtrace.h"


class Foci:public Csapat{
    int edzo;
public:

    Foci(std::string str="", int n=0, int a=0):Csapat(str,n), edzo(a){}
    int getEdzo(){return edzo;}


    void setter(){
        setName();
        setNum();
        std::cout<<"How many COACH?"<<std::endl;
        std::cin>>edzo;
    }

    void print() const {
        std::cout <<"\tFOOTBALL TEAM\n"<<"\tTEAM-NAME:\t"<<nev<<
        "\n\tPLAYERS:\t"<<letszam<<"\n\tTEAMCOACH:\t"<< edzo <<std::endl;
    }

     void printf(std::ofstream &os) const{
         os<<"2 "<< edzo <<" "<< letszam <<" -"<<nev<<std::endl;
     }
    ~Foci(){}
};


#endif // FOCI_H_INCLUDED
