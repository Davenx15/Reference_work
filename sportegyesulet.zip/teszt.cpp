#include "teszt.h"


void teszt(){
    ///Csapatok tesztje
    TEST(Kosar, Konstruktor)
    {
        Kosar a;
        if (a.getPom()!=0)
            FAIL() << " nem 0 a pommpom lanyok szama";
        if (a.getLetszam() !=0)
            FAIL() << " nem 0 a csapat letszama";
        if (a.getNev() != "")
            FAIL() << " nem ures a csapat neve";

        Kosar a2("Kosar FC", 11, 3);
        if  (a2.getPom() != 3)
            FAIL() << " nem 3 az edzok szama";
        if (a2.getLetszam() != 11)
            FAIL() << " nem 11 a csapat letszama";
        if (a2.getNev() != "Kosar FC")
            FAIL() << " nem jo a csapat neve";
    }ENDM

    TEST(Foci, Konstruktot)
    {
        Foci b;
        if (b.getEdzo()!=0)
            FAIL() << " nem 0 az edzok szama";
        if (b.getLetszam() !=0)
            FAIL() << " nem 0 a csapat letszama";
        if (b.getNev() != "")
            FAIL() << " nem ures a csapat neve";
        Foci b2("Foci FC", 11, 3);
        if  (b2.getEdzo()!=3)
            FAIL() << " nem 3 az edzok szama";
        if (b2.getLetszam() != 11)
            FAIL() << " nem 11 a csapat letszama";
        if (b2.getNev() != "Foci FC")
            FAIL() << " nem jo a csapat neve";
    }ENDM

     TEST(Kezi, Konstruktor)
    {
        Kezi c;
        if (c.getPenz()!=0)
            FAIL() << " nem 0 a penz";
        if (c.getLetszam() !=0)
            FAIL() << " nem 0 a csapat letszama";
        if (c.getNev() != "")
            FAIL() << " nem ures a csapat neve";
        Kezi c2("Kezi FC", 11, 3.3);
        if  (c2.getPenz()!= 3.3)
            FAIL() << " nem 3.3 a penz";
        if (c2.getLetszam() != 11)
            FAIL() << " nem 11 a csapat letszama";
        if (c2.getNev() != "Kezi FC")
            FAIL() << " nem jo a csapat neve";
    }ENDM

    ///Lista tesztje.
    TEST(Lista, Konstruktor)
    {
        Lista lista;
        if(lista.getdb() != 0)
            FAIL() << "nem 0 a lista merete";
    }ENDM

    TEST(Lista, add)
    {
        Kosar *uj;
        uj=new Kosar;
        Lista lista;
        lista.add(uj);
        EXPECT_EQ(1, lista.getdb())<< "csapat nem lett hozzaadva a listahoz"<<std::endl;
    }ENDM

    TEST(Lista, add5)
    {
        Lista lista;
        Kosar *uj;
        for(int i=0; i < 5; i++){
            uj=new Kosar;
            lista.add(uj);
        }
        EXPECT_EQ(5, lista.getdb())<< "nem lett elegendo csapat hozzaadva"<<std::endl;
    }ENDM

}
