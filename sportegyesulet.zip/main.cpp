///Ékezetes betük,karakterek használata a program futása során erõsen tilos!
///A hibás menüpont megadásokat a program kritikus helyeken kezeli, de ajánlott ezek mellõzése
#include <iostream>
#include <fstream>
#include <string>

#include "Csapat.h"
#include "Kosar.h"
#include "Foci.h"
#include "Kezi.h"
#include "Lista.h"
#include "teszt.h"

#include "memtrace.h"


int main(){
    teszt();        //tesztek futtatása
    system("cls");
    bool megy=true;
    int kod,menupont;
    Lista lista;
    Csapat *point;
    try{
    std::ifstream inf("adatok.txt");            //adatok.txt az adatok tárolása
    if (inf.is_open()){lista.feltolt(inf);};    //ha nem létezik a fájl lépjen tovább, ha létezik töltse fel a listát
    while(megy){
        std::cout<<"\t\t\t\tFITT SPORTCLUB\n\n";
        lista.kiir();       //kiírja a csapatokat
        std::cout<<"0-ADD NEW TEAM\n1-DELETE TEAM\n9-SAVE AND EXIT"<<std::endl;
        std::cin>>menupont;     // 0, 1, 9 menüpont közül választhat.
        if (menupont==0){       //Listához hozzáadás
            std::cout<<"What team would you like to add?\n1.BASCHETBALL\n2.FOOTBALL\n3.HANDBALL"<<std::endl;
            std::cin>>kod;
        if (kod==1){
            point=new Kosar;        //Kosarra mutató pointer
            point->setter();        //amire mutat a pointer feltöltjük adatokkal majd
            lista.add(point);       //odaadjuk az add()-nak.
        }
        if (kod==2){
            point=new Foci;
            point->setter();
            lista.add(point);
        }
        if (kod==3){
            point=new Kezi;
            point->setter();
            lista.add(point);
        }
        }else if (menupont==1)
                lista.delete_team();        //lista törlése
            else if (menupont==9)           //mentés és kilépés
                megy=false;
        system("cls");
    }
        std::ofstream outf("adatok.txt");
        lista.visszair(outf);

    }

    catch (const char* hiba){  //a törlésnél nemlétező csapat indexét adja meg
        std::cerr<<"The index you selected does not exist!"<<std::endl;
        std::cerr<<"Restart the program! (Changes are not saved) "<<std::endl;
    }

	return 0;

}

