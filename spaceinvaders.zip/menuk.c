#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#include <unistd.h>
#include "menuk.h"
#include "dicslista.h"
#include "debugmalloc.h"

char *nev_olvas() {
    int db = 0;
    char *nev=(char*) malloc(1*sizeof(char));
    nev[0] = '\0';
    char c;
    char atvesz;
    scanf("%c",&atvesz); //a fomenubol egy enter atcsuszik
    printf("What's your name:");
    while (scanf("%c", &c) == 1 && c != '\n') {
        char *ujtomb = (char*) malloc(sizeof(char) * (db+1+1)); //tomb nyujtas
        for (int i = 0; i < db; ++i)
            ujtomb[i] = nev[i];
        free(nev);
        nev = ujtomb;
        ujtomb[db] = c;
        ujtomb[db+1] = '\0';
        ++db;
    }
    return nev;
}

int nehezseg_valaszto(){
    char c;
    while(true){
        printf("DIFFICULTY LEVEL:\n\n");
        printf("1 <Easy>\n");
        printf("2 <Medium>\n");
        printf("3 <Hard>\n");
        printf("Choose:");
        scanf("%c", &c);
        system("cls");
        if (c=='1') return 1;
        if (c=='2') return 2;
        if (c=='3') return 3;
    }
}


int fomenu_loop(int *nehezseg){
    char c='4';
    int vissza=0;
    while (c!='3'){
        printf("                                          S P A C E    I N V A D E R S!!!\n\n");
        printf("0 <Start>\n");
        printf("1 <Top players>\n");
        printf("2 <Info>\n");
        printf("3 <Quit>\n");
        printf("Choose:");
        scanf("%c",&c);
        system("cls");
        if (c=='0'){
            *nehezseg=nehezseg_valaszto();
            return 1;
        }
        if (c=='1'){
            FILE* p;
            char olvasott;
            p=fopen("dicsoseglista.txt","rt");
            if (p==NULL)
                printf("File does not exist(dicsoseglista.txt)");
            else{
            printf("TOP PLAYERS:\n\n");
            while (fscanf (p, "%c", &olvasott) == 1)
                printf("%c", olvasott);
            fclose(p);
            }
        vissza=1;
        while (vissza!=3){
            printf("\n3 <Back>\n");
            printf("Choose:");
            scanf("%d",&vissza);
            system("cls");
        }
        }
        if (c=='2'){
            vissza=1;
            while (vissza!=3){
                printf("CONTROLLS\n");
                printf("Left = KEY_LEFT\nRight = KEY_RIGHT\nShoot = SPACE\n");
                printf("\n\nPoint system:\nEasy-10point/enemy\nNormal-20point/enemy\nHard-30point/enemy\n\n3 <Back>\n");
                printf("Choose:");
                scanf("%d", &vissza);
                system("cls");
            }
        }
    }
    return 0;
}


int kozte_menu_loop(int szint,unsigned long int pont,int elet,char *nev){
        char c='4';
        while (c!='3'){
            printf("Congratulations! You have completed the %d. level!\n", szint);
            printf("0 <Game reset>\n");
            printf("1 <Next level>\n");
            printf("2 <Stats>\n");
            printf("3 <Quit>\n");
            printf("Choose:");
            scanf("%c", &c);
            system("cls");
            if (c=='1') return 1;
            if (c=='2'){
                printf("Point-%lu\nLife-%d ", pont,elet);
                sleep(2);
            }
            if (c=='0'){
                free(nev);
                return 0;
            }
        }
        free(nev);
        return 3;
}



int vege_menu_loop(char *nev,unsigned long int pont){
    char c='4';
    FILE *p;
    p=fopen("dicsoseglista.txt","at"); //nevet berakja a fileba
    fprintf(p,"%s-%lu",nev,pont);
    fclose(p);
    free(nev);
    listaelem *eleje=listaba_beolvas_filebol(); //filebol neveket-pontokat beolvassa listaba
    if (eleje == NULL) return 0;
    lista_kiirasa_fileba(eleje);      //visszairja fileba a rendezett listat
    lista_felszabadit(eleje);         //felszabaditja a listat
    while (c!='3'){
        printf("You died!\nYou earned %lu point!\n\n", pont);
        printf("0 <Main menu>\n");
        printf("3 <Quit>\n");
        printf("Choose:");
        scanf("%c",&c);
        system("cls");
        if (c=='0') return 1;
        }
        return 0;
}

