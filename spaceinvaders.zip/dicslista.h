#ifndef DICSLISTA_H_INCLUDED
#define DICSLISTA_H_INCLUDED

typedef struct listaelem{
    char *nev;
    unsigned long int pont;
    struct listaelem *kov;
}listaelem;

listaelem *uj(char const *nev, unsigned long int szpont);

listaelem *epit(listaelem *eleje, listaelem *uj);

listaelem* listaba_beolvas_filebol();

void lista_kiirasa_fileba(listaelem *eleje);

void lista_felszabadit(listaelem *eleje);

#endif // DICSLISTA_H_INCLUDED
