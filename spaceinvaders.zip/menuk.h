#ifndef MENUK_H_INCLUDED
#define MENUK_H_INCLUDED


int nehezseg_valaszto();

char *nev_olvas();

int fomenu_loop(int *nehezseg);

int kozte_menu_loop(int szint,unsigned long int pont,int elet,char *nev);

int vege_menu_loop(char *nev,unsigned long int pont);

#endif
