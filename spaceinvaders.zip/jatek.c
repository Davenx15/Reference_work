#include "jatek.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <SDL2/SDL_image.h>
#include <time.h>
#include <stdbool.h>
#include <stdlib.h>
#include "debugmalloc.h"



void ablakmegnyitas(int szeles, int magas, SDL_Window **pwindow, SDL_Renderer **prenderer) {
    if (SDL_Init(SDL_INIT_EVERYTHING) < 0) {
        SDL_Log("Nem indithato az SDL: %s", SDL_GetError());
        exit(1);
    }
    SDL_Window *window = SDL_CreateWindow("SDL peldaprogram", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, szeles, magas, 0);
    if (window == NULL) {
        SDL_Log("Nem hozhato letre az ablak: %s", SDL_GetError());
        exit(1);
    }
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    if (renderer == NULL) {
        SDL_Log("Nem hozhato letre a megjelenito: %s", SDL_GetError());
        exit(1);
    }
    SDL_RenderClear(renderer);

    *pwindow = window;
    *prenderer = renderer;
}

tulajdonsag **invaderek(tulajdonsag **tomb){
    tomb=(tulajdonsag **)malloc(24* sizeof(tulajdonsag *));  //24 ellenfel van
    int kezdx=0;
    int kezdy=50;
    for(int i=0;i<24;i++){
        tomb[i]=(tulajdonsag *) malloc(sizeof(tulajdonsag));
        tomb[i]->el=true;
        tomb[i]->x=kezdx;
        tomb[i]->y=kezdy;
        kezdx+=50;
        if (kezdx==400){
            kezdx=0;
            kezdy+=50;
        }
    }
    return tomb;
}

void en_altalanos(SDL_Renderer *renderer,tulajdonsag *en){
    if (en->mozog.balra)
        en->x-=5;
    if (en->mozog.jobbra)
        en->x+=5;
    if (en->meg_lo){
        en->lo_y -= 10;
        filledCircleRGBA(renderer, en->lo_x, en->lo_y, 3, 255, 0, 0, 255);   //enlovesem
    }
    if (en->lo_y<=10)
        en->meg_lo=false;
    filledCircleRGBA(renderer, en->x , en->y , en->r, 0, 255, 255, 255);  //engem rajzol
}

void invader_kirajzolas(SDL_Renderer *renderer,tulajdonsag *ellenseg,tulajdonsag **tomb,tulajdonsag *en,int *ossz,int *nehezseg,unsigned long int *pont){
    for (int i=0;i<24;i++){
        if (ellenseg->mozog.jobbra) {
            tomb[i]->x++;
            if((tomb[i]->el) && (tomb[i]->x == 1000)){
                ellenseg->mozog.jobbra=false;
                ellenseg->mozog.balra=true;
            }
        }
        if (ellenseg->mozog.balra){
            tomb[i]->x--;
            if((tomb[i]->el) && (tomb[i]->x == 10)){
                ellenseg->mozog.balra=false;
                ellenseg->mozog.jobbra=true;
        }
    }
    if ( (en->meg_lo) && (en->lo_y==tomb[i]->y) && (en->lo_x<=(tomb[i]->x)+20) && (en->lo_x>=(tomb[i]->x)-20) && (tomb[i]->el) ){   //ellenfelet eltal�ltam
        tomb[i]->el=false;
        *ossz+=1;
        en->meg_lo=false;
        if (*nehezseg==1) *pont+=10;
        if (*nehezseg==2) *pont+=20;
        if (*nehezseg==3) *pont+=30;
    }
    if (tomb[i]->el)
        filledCircleRGBA(renderer, tomb[i]->x, tomb[i]->y, 15, 255, 0, 255, 255);  //ellensegek kirajzolasa
    }
}

void invaderek_lovesei(SDL_Renderer *renderer,tulajdonsag *ellenseg,tulajdonsag **tomb,tulajdonsag en,int *elet){
    int go;
    while (!ellenseg->meg_lo){
        go=rand()%24;
        if (tomb[go]->el){
            ellenseg->lo_x=tomb[go]->x;
            ellenseg->lo_y=tomb[go]->y;
            ellenseg->meg_lo=true;  //csak egy loves engedelyezett
            break;
        }
    }
    ellenseg->lo_y+=10;    //ellenseges golyo gyorsasag
    filledCircleRGBA(renderer, ellenseg->lo_x, ellenseg->lo_y, 3, 255, 0, 0, 255);
    if (ellenseg->lo_y>=580) ellenseg->meg_lo=false; //ha kiment a palyarol megint lohet
    if ((ellenseg->lo_y>=570) && (ellenseg->lo_x-25<=en.x) && (ellenseg->lo_x+25>=en.x)){  //ha az ellens�g eltal�l engem �letveszt�s.
        *elet-=1;
        ellenseg->meg_lo=false;
    }
}

void start_game(int *elet,int *nehezseg,bool *win,unsigned long int *pont,char *nev){
    srand(time(NULL));
    SDL_Window *window;
    SDL_Renderer *renderer;
    ablakmegnyitas(1000, 600, &window, &renderer);

    tulajdonsag **tomb=NULL;
    tomb=invaderek(tomb);                 //t�mb tartalmazza az invadereket
    tulajdonsag en;
    tulajdonsag ellenseg,ellenseg2;
    en.x=250;
    en.y=580;
    en.r=20;
    en.mozog.balra=false;
    en.mozog.jobbra=false;

    ellenseg.mozog.balra=false;
    ellenseg.mozog.jobbra=true;  //jobbra indul
    ellenseg.r=15;
    ellenseg.meg_lo=false;
    ellenseg2.meg_lo=false;

    int ossz=0; //megolt invaderek
    bool megy=true;
    while (megy){    //esemenyvezerelt ciklus
        SDL_Event event;
        while(SDL_PollEvent(&event)){
            switch(event.type){
            case SDL_KEYDOWN:
                switch (event.key.keysym.sym){
                case SDLK_RIGHT:
                    en.mozog.jobbra=true;
                    break;
                case SDLK_LEFT:
                    en.mozog.balra=true;
                    break;
                case SDLK_SPACE:
                    if (!en.meg_lo){
                    en.lo_x=en.x;
                    en.lo_y=560;
                    en.meg_lo=true;
                    }
                    break;
                }
                break;
            case SDL_KEYUP:
                switch (event.key.keysym.sym){
                case SDLK_RIGHT:
                    en.mozog.jobbra=false;
                    break;
                case SDLK_LEFT:
                    en.mozog.balra=false;
                    break;
                }
            break;
            }
        }
        boxRGBA(renderer, 0,  0,  1000 ,600, 0, 0, 0, 255);

        en_altalanos(renderer,&en);  //engem es lovesem kirajzolas
        invader_kirajzolas(renderer,&ellenseg,tomb,&en,&ossz,nehezseg,pont);  //invader kirajzolas
        invaderek_lovesei(renderer,&ellenseg,tomb,en,elet);                                                         //csak 1 loves engedelyezett
        if ((*nehezseg==3) && (ossz!=23))
            invaderek_lovesei(renderer,&ellenseg2,tomb,en,elet); //2loves engedelyezett

        for (int i=0; i<*elet; i++) //elet kirajzolas
            filledCircleRGBA(renderer, 40+i*15,  10, 5, 0, 255, 255, 255);

        if (*elet==0){
            *win=false;
            megy=false;
            for (int i=0; i<24; i++){
                free(tomb[i]);
            }
            free(tomb);
        }
        if (ossz==24){
            *win=true;
            megy=false;
            for (int i=0; i<24; i++){
                free(tomb[i]);
            }
            free(tomb);
        }
        SDL_RenderPresent(renderer);
        SDL_Delay(18);
    }
    SDL_Quit();
}
