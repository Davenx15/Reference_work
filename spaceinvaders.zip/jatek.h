#ifndef JATEK_H_INCLUDED
#define JATEK_H_INCLUDED
#include <stdbool.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <SDL2/SDL_image.h>

typedef struct mozog{
    bool balra;
    bool jobbra;
}mozog;

typedef struct tulajdonsag{
    int x,y;
    int lo_x,lo_y;
    bool meg_lo;
    int r;
    mozog mozog;
    bool el;
}tulajdonsag;


tulajdonsag *ellenfelek();

void ablakmegnyitas(int szeles, int magas, SDL_Window **pwindow, SDL_Renderer **prenderer);

void en_altalanos(SDL_Renderer *renderer,tulajdonsag *en);

void start_game(int *elet,int *nehezseg,bool *win,unsigned long int *pont,char *nev);

void invader_kirajzolas(SDL_Renderer *renderer,tulajdonsag *ellenseg,tulajdonsag **tomb,tulajdonsag *en,int *ossz,int *nehezseg,unsigned long int *pont);

void invaderek_lovesei(SDL_Renderer *renderer,tulajdonsag *ellenseg,tulajdonsag **tomb,tulajdonsag en,int *elet);

#endif
