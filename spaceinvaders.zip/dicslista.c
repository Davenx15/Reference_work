#include "dicslista.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "debugmalloc.h"

//letrehozza a lista uj elemet
listaelem *uj(char const *nev, unsigned long int szpont) {
    listaelem *uj;
    uj = (listaelem*) malloc(sizeof(listaelem));
    uj->kov = NULL;
    uj->nev = (char*) malloc(sizeof(char)*(strlen(nev)+1));
    uj->pont=szpont;
    strcpy(uj->nev, nev);
    return uj;
}

//mar rendezve felepiti a listat
listaelem *epit(listaelem *eleje, listaelem *uj){
    listaelem *lemarado = NULL;
    listaelem *mozgo = eleje;
    while (mozgo != NULL && mozgo->pont > uj->pont) {
        lemarado = mozgo;
        mozgo = mozgo->kov;
    }

    if (lemarado == NULL) {   //ha elso helyre kell ker�lj�n az elem
        uj->kov = eleje;
        eleje = uj;
    } else {
        lemarado->kov = uj;  //ha elemek k�z�
        uj->kov = mozgo;
    }
    return eleje;
}

//FILE-bol berakja az elemeket egy list�ba
listaelem *listaba_beolvas_filebol(){
    listaelem *eleje=NULL;
    FILE *p;
    p=fopen("dicsoseglista.txt","rt");
    if (p == NULL){
        printf("File does not exist(dicsoseglista.txt)");
        return NULL;
    }else{
    unsigned long int szpont;
    int db = 0;
    char *nev= (char*) malloc(sizeof(char) * 1);
    nev[0]='\0';
    char c;
    while (fscanf(p,"%c", &c) != EOF) {
        if (c!='-'){        //- fontos jel, ez v�lasztja el a stringet a sz�mt�l
            if (c!='\n'){  //tetszolegesen hossz� string kiolvas�s
            char *ujtomb = (char*) malloc(sizeof(char) * (db+1+1));
            for (int i = 0; i < db; ++i)
            ujtomb[i] = nev[i];
            free(nev);
            nev = ujtomb;
            ujtomb[db] = c;
            ujtomb[db+1] = '\0';
            ++db;
            }
        }else{ //szam beolvasas
            fscanf(p,"%lu", &szpont);
            listaelem *ujtag=uj(nev,szpont);
            eleje=epit(eleje,ujtag);
            free(nev);
            nev = (char*) malloc(sizeof(char) * 1);
            nev[0]='\0';
            db = 0;
        }
    }
    free(nev);
    }
    fclose(p);
    return eleje;
}

void lista_kiirasa_fileba(listaelem *eleje){
    listaelem *mozgo;
    FILE *p;
    p=fopen("dicsoseglista.txt","wt");
    int top=10;   //top ? legyen ki�rva
    int topdb=0;
    for (mozgo = eleje; mozgo != NULL; mozgo = mozgo->kov){
        if (topdb<top)
            fprintf(p,"%s-%lu\n", mozgo->nev,mozgo->pont);
        else
            break;
    topdb++;
    }
    fclose(p);
}

//lista felszabad�t�sa, a benne levo nevekkel egy�tt
void lista_felszabadit(listaelem *eleje){
    listaelem *iter = eleje;
    while (iter != NULL) {
        listaelem *kov = iter->kov;
        free(iter->nev);
        free(iter);
        iter = kov;
    }
}

