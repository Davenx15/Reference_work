﻿#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>
#include "menuk.h"
#include "jatek.h"



int main(int argc, char *argv[]) {

    int nehezseg;
    int elet;
    char *nev;
    bool win=false;
    while (true){
        if (fomenu_loop(&nehezseg)==0) return 0; //program inditása
        nev=nev_olvas();
        system("cls");
        unsigned long int pont=0;
        int ertek=0;   //a kozte-menu visszateritesi ertekenek atlathatosaga miatt
        if (nehezseg!=1)
            elet=1;
        else
            elet=3;
        bool kovi_szint=true;
        int szint=0;
            while (kovi_szint){ //ha szintek teljesulnek
                start_game(&elet,&nehezseg,&win,&pont,nev);
                if (win==true){
                    szint++;
                    ertek=kozte_menu_loop(szint,pont,elet,nev);
                    if (ertek==3) return 0;
                    else if (ertek==0) break;
                }else kovi_szint=false;  //ha meghalsz
            }
        if (vege_menu_loop(nev,pont)==0) return 0;
    }
    return 0;
}

