package Menu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.Timer;
import javax.swing.WindowConstants;

import Game.GameDisplay;

public class MenuDisplay extends JFrame implements MouseListener, ActionListener {

	/**
	* 
	*/
	private MenuGraph menu;
	private Timer timer;

	private static final long serialVersionUID = 1L;

	public MenuDisplay() {
		menu = new MenuGraph();
		add(menu);
		menu.addMouseListener(this);

		timer = new Timer(10, this);
		timer.start();

		setSize(600, 600);
		setLocationRelativeTo(null);
		setResizable(false);
		setLayout(null);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setVisible(true);

	}

	@Override
	public void mouseClicked(MouseEvent e) {

		int x = e.getX();
		int y = e.getY();
		// NewGame
		if ((x > 150) && (x < 420) && (y > 0) && (y < 50)) {
			dispose();
			File save = new File("Save");
			save.delete();
			timer.stop();
			new GameDisplay();
		}
		// Continue(ha nincs ment�s akkor is �jjat kezd) !! J�-e !!
		if ((x > 150) && (x < 420) && (y > 50) && (y < 100)) {
			dispose();
			timer.stop();
			new GameDisplay();
		}
		// Exit
		if ((x > 150) && (x < 420) && (y > 100) && (y < 150)) {
			System.exit(0);
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		menu.repaint();
	}

}
