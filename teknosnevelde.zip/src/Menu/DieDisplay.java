package Menu;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class DieDisplay extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Image img;

	public DieDisplay() {
		File save = new File("Save");
		save.delete();
		ImageIcon imageIcon = new ImageIcon("kepek/tengerpart.png");
		imageIcon.setImage(imageIcon.getImage().getScaledInstance(600, 300, Image.SCALE_DEFAULT));
		img = imageIcon.getImage();
		setSize(600, 300);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setResizable(false);
		setVisible(true);
	}

	public void paint(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.drawImage(img, 0, 0, null);
		g2d.setColor(Color.black);
		g2d.setFont(new Font("Ink Free", Font.BOLD, 150));
		g2d.drawString("Died!", 150, 200);
	}
}
