package Menu;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class MenuGraph extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Image img;
	private Color colorNew;
	private Color colorContinue;
	private Color colorExit;

	public MenuGraph() {
		ImageIcon imageIcon = new ImageIcon("kepek/menuGif.gif");
		setOpaque(false);

		setBounds(0, 0, 600, 600);
		imageIcon.setImage(imageIcon.getImage().getScaledInstance(600, 600, Image.SCALE_DEFAULT));
		img = imageIcon.getImage();
		setVisible(true);

		addMouseMotionListener(new MouseMotionListener() {
			@Override
			public void mouseDragged(MouseEvent e) {

			}

			@Override
			public void mouseMoved(MouseEvent e) {
				int x = e.getX();
				int y = e.getY();
				if ((x > 150) && (x < 420) && (y > 0) && (y < 50)) {
					colorNew = Color.yellow;
				} else
					colorNew = Color.black;
				if ((x > 150) && (x < 420) && (y > 50) && (y < 100)) {
					colorContinue = Color.yellow;
				} else
					colorContinue = Color.black;
				if ((x > 150) && (x < 420) && (y > 100) && (y < 150)) {
					colorExit = Color.yellow;
				} else
					colorExit = Color.black;
			}
		});
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.drawImage(img, 0, 0, null);
		g2d.setPaint(colorNew);
		g2d.setFont(new Font("Ink Free", Font.BOLD, 50));
		g2d.drawString("New Turtle", 150, 50);
		g2d.setPaint(colorContinue);
		g2d.drawString("Continue", 150, 100);
		g2d.setPaint(colorExit);
		g2d.drawString("Exit", 150, 150);
	}

}
