package Resource;

import java.awt.Graphics2D;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Turtle implements Serializable {

	private static final long serialVersionUID = 1L;
	// mert mindennek k�l�nb�z� �rt�kei �s cs�kken�si ideje lehet;
	private List<Attributes> atr;
	private HashMap<String, Item> ownedItems;

	public Turtle() {
		atr = new ArrayList<Attributes>();
		ownedItems = new HashMap<String, Item>();
		try {
			ObjectInputStream in = new ObjectInputStream(new FileInputStream("Save"));
			Turtle readObject = (Turtle) in.readObject();
			atr = readObject.getAllAtr();
			ownedItems = readObject.getAllItems();
			in.close();
		} catch (IOException ex) {
			addAtrToList(new Attributes("kaja", 100, 20));
			addAtrToList(new Attributes("viz", 100, 10));
			addAtrToList(new Attributes("tiszt", 100, 60));
			addAtrToList(new Attributes("hom", 100, 30));
			addAtrToList(new Attributes("nap", 0, 1800));
			addAtrToList(new Attributes("penz", 10, 0));

		} catch (ClassNotFoundException ex) {
			System.out.print(ex.getMessage());
		}
	}

	public void csokkent(long sec) {
		if (getAtr("kaja").descrase(sec))
			if (getAtr("hom").getValue() <= 50) {
				descValueOfAtr("kaja", 2); // 2vel cs�kkenti kaja �rteket
			} else
				descValueOfAtr("kaja", 1);// 1el cs�kkenti kaja �rteket

		if (getAtr("viz").descrase(sec))
			if (getAtr("tiszt").getValue() <= 50)
				descValueOfAtr("viz", 2);
			else
				descValueOfAtr("viz", 1);

		if (getAtr("hom").descrase(sec))
			if (getAtr("tiszt").getValue() <= 50) {
				descValueOfAtr("hom", 2);
			} else
				descValueOfAtr("hom", 1);

		if (getAtr("tiszt").descrase(sec))
			descValueOfAtr("tiszt", 1);

		if (getAtr("nap").descrase(sec))
			getAtr("nap").setValue(getAtr("nap").getValue() + 1);
	}

	public void addAtrToList(Attributes attrib) {
		atr.add(attrib);
	}

	private List<Attributes> getAllAtr() {
		return atr;
	}

	public void descValueOfAtr(String nev, int desc) {
		getAtr(nev).setValue(getAtr(nev).getValue() - desc);
	}

	public boolean meghalt() {
		if (getAtr("kaja").getValue() <= 0 || getAtr("viz").getValue() <= 0 || getAtr("hom").getValue() <= 0
				|| getAtr("tiszt").getValue() == 0)
			return true;
		else
			return false;
	}

	public HashMap<String, Item> getAllItems() {
		return ownedItems;
	}

	public void getDress(Graphics2D g2d) {
		Item tiszt = ownedItems.get("tiszt");
		if (tiszt != null) {
			if (g2d != null)
				tiszt.paint(g2d);
			getAtr("tiszt").setDescTime(getAtr("tiszt").getBaseDescTime() + tiszt.getIdo());
		}
		Item hom = ownedItems.get("hom");
		if (hom != null) {
			if (g2d != null)
				hom.paint(g2d);
			getAtr("hom").setDescTime(getAtr("hom").getBaseDescTime() + hom.getIdo());
		}
	}

	public Attributes getAtr(String nev) {
		for (int i = 0; i < atr.size(); i++) {
			if (atr.get(i).getNev().equals(nev))
				return atr.get(i);
		}
		return null;
	}

	public void addItem(String nev, Item a) {
		ownedItems.put(nev, a);
	}

}
