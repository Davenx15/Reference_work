package Resource;

import java.awt.Graphics;
import java.awt.Image;
import java.io.Serializable;

import javax.swing.ImageIcon;

public class Item implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int ido;
	private String nev;

	public Item(String nev, int kesleltetett) {
		this.ido = kesleltetett;
		this.nev = nev;

	}

	public void paint(Graphics g2d) {
		ImageIcon imageIcon = new ImageIcon("kepek/" + nev + ".png");
		imageIcon.setImage(imageIcon.getImage().getScaledInstance(600, 600, Image.SCALE_DEFAULT));
		Image img = imageIcon.getImage();
		g2d.drawImage(img, 0, 0, null);
	}

	public int getIdo() {
		return ido;
	}

	public void setIdo(int ido) {
		this.ido = ido;
	}

}
