package Resource;

import java.io.Serializable;

public class Attributes implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int baseDescTime;
	private int descTime;
	private int value;
	private String nev;
	
	public Attributes(String nev,int value,int time) {
		this.value=value;
		baseDescTime=time;
		descTime=time;
		this.nev=nev;
	}
	
	public boolean descrase(long sec) {
		if (sec % descTime==0) return true;
		else return false;
	}

	public int getDescTime() {
		return descTime;
	}

	public void setDescTime(int descTime) {
		this.descTime = descTime;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public int getBaseDescTime() {
		return baseDescTime;
	}

	public String getNev() {
		return nev;
	}

	public void setNev(String nev) {
		this.nev = nev;
	}

	public void setBaseDescTime(int baseDescTime) {
		this.baseDescTime = baseDescTime;
	}
	
}
