package MiniGame;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

import Resource.Turtle;


public class MiniGameGraph extends JPanel implements ActionListener{

	private static final long serialVersionUID = 1L;
	
	private Image backround;
	private Image miniturtle;
	private boolean turtleMoveRight;
	private boolean turtleMoveLeft;
	private int turtleX;
	private List<MiniCoin> coins;
	private Timer drawTimer;
	private Turtle turtle;
	
	public MiniGameGraph(Turtle turtle) {
		this.turtle=turtle;
		coins=new ArrayList<>();
		ImageIcon imageIcon =new ImageIcon("kepek/miniBackround.png");
		imageIcon.setImage(imageIcon.getImage().getScaledInstance( 600, 565, Image.SCALE_DEFAULT));
		backround=imageIcon.getImage();
		drawTimer=new Timer(1, this);
		drawTimer.start();
		
		imageIcon = new ImageIcon("kepek/miniTurtle.png");
		imageIcon.setImage(imageIcon.getImage().getScaledInstance(60, 60, Image.SCALE_DEFAULT));
		miniturtle = imageIcon.getImage();
		
		turtleX= 200;
		turtleMoveRight=false;
		turtleMoveLeft=false;
	}
	
	public void pressedRight() {
		if (turtleX < 520)
			turtleX+=3;
	}
	public void pressedLeft() {
		if (turtleX > 10)
			turtleX-=3;
	}
	
	
	public void paint(Graphics gd) {
		Graphics2D g2d=(Graphics2D)gd;
		g2d.drawImage(backround, 0, 0, null);
		g2d.drawImage(miniturtle, turtleX, 480, null);
		dropCoin(g2d);
	}

	public int getTurtleX() {
		return turtleX;
	}

	public boolean getTurtleMoveRight() {
		return turtleMoveRight;
	}

	public boolean getTurtleMoveLeft() {
		return turtleMoveLeft;
	}

	public void setTurtleMoveRight(boolean b) {
		turtleMoveRight=b;	
	}

	public void setTurtleMoveLeft(boolean b) {
		turtleMoveLeft=b;
		
	}
	
	public void addCoin(MiniCoin c){
		coins.add(c);
	}

	public void dropCoin(Graphics2D g2d) {
		for(int i=0; i<coins.size(); i++) {
			MiniCoin coin= coins.get(i);
			coin.fallCoin();
			if (g2d!=null) coin.paint(g2d);
			
			if (coin.getY() >=500 ) {
				coins.remove(i);
				
			}
			if (coin.getY() <500 && coin.getY()>450 && coin.getX()>turtleX && coin.getX() < turtleX+50) {
				turtle.getAtr("penz").setValue(turtle.getAtr("penz").getValue()+1);
				coins.remove(i);
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		repaint();
		if(getTurtleMoveRight()) 
			pressedRight();
		if(getTurtleMoveLeft())
			pressedLeft();
	}


}
