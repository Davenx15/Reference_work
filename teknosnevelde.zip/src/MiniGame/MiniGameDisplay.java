package MiniGame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.Timer;
import javax.swing.WindowConstants;

import Resource.Turtle;

public class MiniGameDisplay extends JFrame implements KeyListener, ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private MiniGameGraph miniGame;
	private Timer timer; // create coins

	public MiniGameDisplay(Turtle turtle) {
		miniGame = new MiniGameGraph(turtle);
		addKeyListener(this);
		add(miniGame);

		timer = new Timer(800, this);
		timer.start();

		setVisible(true);
		setSize(600, 600);
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		miniGame.addCoin(new MiniCoin());
	}

	@Override
	public void keyTyped(KeyEvent e) {

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			miniGame.setTurtleMoveRight(true);
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			miniGame.setTurtleMoveLeft(true);
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_LEFT) {
			miniGame.setTurtleMoveLeft(false);
			miniGame.setTurtleMoveRight(false);
		}

	}

}
