package MiniGame;

import java.awt.Graphics2D;
import java.awt.Image;
import java.util.Random;

import javax.swing.ImageIcon;

public class MiniCoin {
	private Image img;
	private int x;
	private int y;
	
	public MiniCoin() {
		int maxX=500;
		int minX=50;
		Random rand = new Random();
		x=rand.nextInt(maxX-minX)+minX;
		y=0;
		
		ImageIcon imageIcon=new ImageIcon("kepek/penz.png");
		imageIcon = new ImageIcon("kepek/penz.png");
		imageIcon.setImage(imageIcon.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT));
		img=imageIcon.getImage();
	}
	
	public void fallCoin() {
		y+=3;
	}
	
	public void paint(Graphics2D g2d) {
		g2d.drawImage(img, x, y, null);
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
}
