package Main;

import Menu.MenuDisplay;

public class Main {
	public static void main(String[] args) {
		new MenuDisplay();
	}
}
