package Game;

import Resource.Turtle;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class GameGraph extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Turtle turtle;
	private Image img;
	private Color colorShop;
	private Color colorGame;
	// timer a k�p folyamatos ujrarajzol�s��rt felel�s(shop/men� m�k�dj�n)
	private Timer timer;

	public GameGraph(Turtle turtle) {
		this.turtle = turtle;
		ImageIcon imageIcon = new ImageIcon("kepek/turtle.png");
		setOpaque(false);
		timer = new Timer(10, this);
		timer.start();
		
		img = imageIcon.getImage();
		setVisible(true);
		addMouseMotionListener(new MouseMotionListener() {
			@Override
			public void mouseDragged(MouseEvent e) {

			}

			@Override
			public void mouseMoved(MouseEvent e) {
				int x = e.getX();
				int y = e.getY();
				// Shop
				if ((x > 50) && (x < 140) && (y > 460) && (y < 500)) {
					colorShop = Color.yellow;
				} else
					colorShop = Color.black;
				// Game
				if ((x > 450) && (x < 560) && (y > 460) && (y < 500)) {
					colorGame = Color.yellow;
				} else
					colorGame = Color.black;
			}
		});
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.drawImage(img, 0, 0, null);
		// kirajzolja ami a teknoson van;
		turtle.getDress(g2d);
		g2d.setPaint(Color.black);
		g2d.setFont(new Font("Ink free", Font.BOLD, 20));
		g2d.drawString("Food:" + turtle.getAtr("kaja").getValue(), 0, 20);
		g2d.drawString("Water:" + turtle.getAtr("viz").getValue(), 100, 20);
		g2d.drawString("Hygenie:" + turtle.getAtr("tiszt").getValue(), 220, 20);
		g2d.drawString("Temperature:" + turtle.getAtr("hom").getValue(), 350, 20);
		g2d.drawString("Day:", 530, 20);
		g2d.drawString("" + turtle.getAtr("nap").getValue(), 540, 40);
		g2d.setStroke(new BasicStroke(2));
		g2d.drawLine(0, 30, 520, 30);
		g2d.drawRect(520, 3, 64, 50);
		g2d.setFont(new Font("Ink free", Font.BOLD, 40));
		g2d.drawString("Gold:" + turtle.getAtr("penz").getValue(), 220, 550);
		g2d.setColor(colorGame);
		g2d.drawString("Game", 450, 500);
		g2d.setColor(colorShop);
		g2d.drawString("Shop", 50, 500);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		repaint();
	}

}
