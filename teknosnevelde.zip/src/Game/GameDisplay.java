package Game;

import MiniGame.MiniGameDisplay;
import Resource.Turtle;
import shop.ShopDisplay;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.swing.*;

import Menu.DieDisplay;

public class GameDisplay extends JFrame implements ActionListener, MouseListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Turtle turtle;
	private GameGraph turtlePanel;
	private Timer timer;
	private long ido;

	public GameDisplay() {
		turtle = new Turtle();
		turtlePanel = new GameGraph(turtle);
		add(turtlePanel);
		turtlePanel.addMouseListener(this);
		timer = new Timer(800, this);
		timer.start();
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				try {
					FileOutputStream f = new FileOutputStream("Save");
					ObjectOutputStream out = new ObjectOutputStream(f);
					out.writeObject(turtle);
					out.close();
				} catch (IOException ex) {
					System.out.print(ex);
				}

			}
		});

		setSize(600, 600);
		setLocationRelativeTo(null);
		setResizable(false);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		ido++;
		turtle.csokkent(ido);
		if (turtle.meghalt()) {
			new DieDisplay();
			timer.stop();
			setVisible(false);
		}
		if (ido == 1800)
			ido = 1;

	}

	@Override
	public void mouseClicked(MouseEvent e) {

		int x = e.getX();
		int y = e.getY();
		// Shop
		if ((x > 50) && (x < 140) && (y > 460) && (y < 500)) {
			new ShopDisplay(turtle);
		}
		// Game
		if ((x > 450) && (x < 560) && (y > 460) && (y < 500)) {
			new MiniGameDisplay(turtle);
		}

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
