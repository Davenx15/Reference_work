package shop;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Resource.Item;

public class ShopGraph extends JPanel implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ShopDisplay shop;
	
	public ShopGraph(ShopDisplay shop) {
		this.shop=shop;
		setLayout(new GridLayout(0,1));
		JButton kaja1=new JButton("+10 food---10 gold");
		JButton kaja2=new JButton("+40 food---35 gold");
		JButton kaja3=new JButton("+60 food---50 gold");
		JButton viz1=new JButton("+10 water---10 gold");
		JButton viz2=new JButton("+40 water---35 gold");
		JButton viz3=new JButton("+60 water---50 gold");
		JButton vizt=new JButton("Cleaning---100 gold");
		JButton vizm=new JButton("Hotting---150 gold");
		JButton rongy=new JButton("Rag(20sec bonus)---100gold");
		JButton kefe=new JButton("Brush(30sec bonus)---200gold");
		JButton sepru=new JButton("Broom(50sec bonus)---500gold");
		JButton sapka=new JButton("Cap(20sec bonus)---150gold");
		JButton sal=new JButton("Scarf(30sec bonus)---250gold");
		JButton kabat=new JButton("Jacket(50sec bonus)---550gold");
		
		kaja1.addActionListener(this);
		kaja2.addActionListener(this);
		kaja3.addActionListener(this);
		viz1.addActionListener(this);
		viz2.addActionListener(this);
		viz3.addActionListener(this);
		vizt.addActionListener(this);
		vizm.addActionListener(this);
		sapka.addActionListener(this);
		sal.addActionListener(this);
		kabat.addActionListener(this);
		rongy.addActionListener(this);
		kefe.addActionListener(this);
		sepru.addActionListener(this);
		
		add(new JLabel("Instant:"));
		add(kaja1);
		add(kaja2);
		add(kaja3);
		add(viz1);
		add(viz2);
		add(viz3);
		add(vizt);
		add(vizm);
		add(new JLabel("Items:"));
		add(sapka);
		add(sal);
		add(kabat);
		add(rongy);
		add(kefe);
		add(sepru);
	
	}
	
	public void actionPerformed(ActionEvent e){
		switch(e.getActionCommand()){
			case "+10 food---10 gold":
				shop.buyInstant("kaja",10,10);
				break;
			case "+40 food---35 gold":
				shop.buyInstant("kaja",40,35);
				break;
			case "+60 food---50 gold":
				shop.buyInstant("kaja",60,50);
				break;
				
			case "+10 water---10 gold":
				shop.buyInstant("viz",10,10);
				break;
			case "+40 water---35 gold":
				shop.buyInstant("viz",40,35);
				break;
			case "+60 water---50 gold":
				shop.buyInstant("viz",60,50);
				break;
				
			case "Cleaning---100 gold":
				shop.buyInstant("tiszt",100,100);
				break;
			case "Hotting---150 gold":
				shop.buyInstant("hom",100,150);
				break;		
				
				
			case "Rag(20sec bonus)---100gold":
				shop.buyItems("tiszt", new Item("rag", 20), 100);
				break;
			case "Brush(30sec bonus)---200gold":
				shop.buyItems("tiszt", new Item("brush", 30), 200);
				break;
			case "Broom(50sec bonus)---500gold":
				shop.buyItems("tiszt", new Item("broom", 50), 500);
				break;
				
				
			case "Cap(20sec bonus)---150gold":
				shop.buyItems("hom", new Item("cap", 20), 150);
				break;
			case "Scarf(30sec bonus)---250gold":
				shop.buyItems("hom", new Item("scarf", 30), 250);
				break;
			case "Jacket(50sec bonus)---550gold":
				shop.buyItems("hom", new Item("jacket", 50), 550);
				break;
				
		}
	}
	
	
}
