package shop;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

import Resource.Item;
import Resource.Turtle;



public class ShopDisplay extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Turtle turtle;
	
	public ShopDisplay(Turtle turtle) {
		this.turtle=turtle;
		add(new ShopGraph(this));
		setSize(500, 600);
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
	}

	public void buyInstant(String atr,int i, int j) {
		if (j<=turtle.getAtr("penz").getValue() && turtle.getAtr(atr).getValue()!=100){
			if (turtle.getAtr(atr).getValue()+i >100) {
				turtle.getAtr(atr).setValue(100);// atr 100
				turtle.getAtr("penz").setValue(turtle.getAtr("penz").getValue()-j);//penz minusz
			}else {
				turtle.getAtr(atr).setValue(turtle.getAtr(atr).getValue()+i);//atr x+i
				turtle.getAtr("penz").setValue(turtle.getAtr("penz").getValue()-j);//penz munusz
			}
		}
	}
	
	public void buyItems(String boost, Item a, int j) {
		if (j <= turtle.getAtr("penz").getValue()) {
			turtle.addItem(boost,a);
			turtle.getAtr("penz").setValue(turtle.getAtr("penz").getValue()-j);
		}
	}
	
}
