package junittest;

import static org.junit.Assert.*;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

import Resource.Attributes;
import Resource.Item;
import Resource.Turtle;

public class TurtleTest {
	private Turtle turtle;
	private Attributes atr1;
	private Attributes atr2;

	@Before
	public void init() {
		File save = new File("Save");
		save.delete();
		turtle = new Turtle();
	}

	@Test
	public void AttributeTest() {
		assertEquals(100, turtle.getAtr("viz").getValue());
		assertEquals(10, turtle.getAtr("viz").getBaseDescTime());
		assertEquals(10, turtle.getAtr("viz").getDescTime());
	}

	@Test
	public void AllAttributeCsokkentTest() {
		turtle.addAtrToList(atr1);
		turtle.addAtrToList(atr2);
		for (int i = 1; i <= 50; i++) {
			turtle.csokkent(i);
		}
		assertEquals(95, turtle.getAtr("viz").getValue());
		assertEquals(98, turtle.getAtr("kaja").getValue());
	}

	@Test
	public void AtributeDescTest() {
		turtle.addAtrToList(atr1);
		turtle.descValueOfAtr("viz", 1);
		assertEquals(99, turtle.getAtr("viz").getValue());
	}

	@Test
	public void AddItemTest() {
		turtle.addAtrToList(new Attributes("tiszt", 100, 60));
		Item item = new Item("kalap", 10);
		turtle.addItem("tiszt", item);
		turtle.getDress(null);
		assertEquals(70, turtle.getAtr("tiszt").getDescTime());
	}

	public void meghaltTest() {
		turtle.getAtr("viz").setValue(0);
		assertTrue(turtle.meghalt());
	}

}
