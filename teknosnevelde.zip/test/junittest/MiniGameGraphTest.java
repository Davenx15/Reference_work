package junittest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import MiniGame.MiniCoin;
import MiniGame.MiniGameGraph;
import Resource.Turtle;

public class MiniGameGraphTest {
	Turtle turtle;
	MiniGameGraph miniGame;

	@Before
	public void init() {
		turtle = new Turtle();
		miniGame = new MiniGameGraph(turtle);
	}

	@Test
	public void turtleMoveRightTest() {
		miniGame.pressedRight();
		assertEquals(203, miniGame.getTurtleX());
	}

	@Test
	public void turtleMoveLeftTest() {
		miniGame.pressedLeft();
		assertEquals(197, miniGame.getTurtleX());
	}

	@Test
	public void coinDroppTest() {
		MiniCoin coin = new MiniCoin();
		miniGame.addCoin(coin);
		miniGame.dropCoin(null);
		assertEquals(3, coin.getY());
	}

	@Test
	public void coinCatchTest() {
		MiniCoin coin = new MiniCoin();
		miniGame.addCoin(coin);
		coin.setX(210);
		for (int i = 0; i < 500; i++) {
			miniGame.dropCoin(null);
		}
		assertEquals(1, turtle.getAtr("penz").getValue());

		MiniCoin coin2 = new MiniCoin();
		miniGame.addCoin(coin2);
		coin2.setX(400);
		for (int i = 0; i < 500; i++) {
			miniGame.dropCoin(null);
		}
		assertEquals(1, turtle.getAtr("penz").getValue());
	}

}
