package junittest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Resource.Item;
import Resource.Turtle;
import shop.ShopDisplay;

public class ShopDisplayTest {
	ShopDisplay shop;
	Turtle turtle;

	@Before
	public void init() {
		turtle = new Turtle();
		shop = new ShopDisplay(turtle);
	}

	@Test
	public void testBuyInstant() {
		turtle.getAtr("viz").setValue(50);
		turtle.getAtr("penz").setValue(100);
		shop.buyInstant("viz", 20, 10);
		assertEquals(70, turtle.getAtr("viz").getValue());
		assertEquals(90, turtle.getAtr("penz").getValue());
	}

	@Test
	public void testBuyItems() {
		turtle.getAtr("penz").setValue(300);
		Item sapka = new Item("sapka", 20);
		shop.buyItems("tiszt", sapka, 200);
		assertEquals(100, turtle.getAtr("penz").getValue());
	}

}
