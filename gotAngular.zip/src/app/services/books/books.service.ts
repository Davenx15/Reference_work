import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from 'rxjs';
import { Book } from 'src/app/model/book';

@Injectable({
  providedIn: 'root'
})
export class BooksService {
  
  constructor(private http: HttpClient) { }

  /**
   * API call to get all the books.
   * @returns Books list.
   */
  getBooks(){
    return this.http.get<Book[]>('https://anapioficeandfire.com/api/books?page=1&pageSize=12');
  }
  /**
   * API call to get all books with a given name.
   * @param name The name of book.
   * @returns Books list
   */
  getBookByName(name: string){
    return this.http.get<Book[]>('https://www.anapioficeandfire.com/api/books?name='+name);
  }
/**
   * API call to get a book with a given URL.
   * @param url The url of book.
   * @returns Book
   */
  getBookByUrl(url: string){
    return this.http.get<Book>(url);
  }
}
