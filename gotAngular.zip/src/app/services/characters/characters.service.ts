import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Character } from 'src/app/model/character';


@Injectable({
  providedIn: 'root'
})
export class CharactersService {
  
  constructor(private http: HttpClient) { }
  /**
   * API call to get all the characters on the current page.
   * @param currentPage The current page.
   * @returns Characters list.
   */
  getCharacters(currentPage: number){
    return this.http.get<Character[]>('https://anapioficeandfire.com/api/characters?page='+currentPage+'&pageSize=10');
  }
  /**
   * API call to get all characters with a given name.
   * @param name The name of character.
   * @returns Characters list
   */
  getCharacterByName(name: string){
    return this.http.get<Character[]>('https://www.anapioficeandfire.com/api/characters?name='+name);
  }
  /**
   * API call to get a character with a given URL.
   * @param url The url of character.
   * @returns Character
   */
  getCharacterByUrl(url: string){
    return this.http.get<Character>(url);
  }
}
