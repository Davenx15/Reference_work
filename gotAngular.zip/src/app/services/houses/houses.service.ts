import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { House } from 'src/app/model/house';

@Injectable({
  providedIn: 'root'
})
export class HousesService {

  constructor(private http: HttpClient) { }
  /**
   * API call to get all the houses on the current page.
   * @param currentPage The current page.
   * @returns Houses list.
   */
  getHouses(currentPage: number){
    return this.http.get<House[]>('https://anapioficeandfire.com/api/houses?page='+currentPage+'&pageSize=10');
  }
  /**
   * API call to get all houses with a given name.
   * @param name The name of house.
   * @returns Houses list
   */
  getHouseByName(name: string){
    return this.http.get<House[]>('https://www.anapioficeandfire.com/api/houses?name='+name);
  }

  /**
   * API call to get a house with a given URL.
   * @param url The url of house.
   * @returns House
   */
  getHouseByUrl(url: string){
    return this.http.get<House>(url);
  }
}
