import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Book } from 'src/app/model/book';
import { BooksService } from 'src/app/services/books/books.service';
import { CharactersService } from 'src/app/services/characters/characters.service';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent {
  public books: Book[] = [];
  searchTerm: string = "";
  searchBookTerm: string = "";
  searchCharacterTerm: string = "";
  openValue: boolean = false;
  LOAD_BOOK_NAME: string= "loadBookName";
  error: boolean = false;
  characterList: string[] = [];

  constructor(private charactersService: CharactersService, private booksService: BooksService, private route: ActivatedRoute, private elementRouter: Router){}
  /**
   * Initialize component, process local storage and navigation details.
   */
  ngOnInit(){
    this.route.params.subscribe((params)=>{
      if(params['name']){
        this.loadBookByName(params['name']);
        localStorage.setItem(this.LOAD_BOOK_NAME, params['name']);
        this.openValue = true;
      }else{
        var loadedBookName = localStorage.getItem(this.LOAD_BOOK_NAME);
        if(loadedBookName){
          this.elementRouter.navigate(['books', loadedBookName]);
        }else{
          this.openValue = false;
          this.getBooks();
        }
      } 
    });
  }
  /**
   * Set books list with books.
   */
  getBooks(){
    this.booksService.getBooks().subscribe((books) =>{
      books.forEach((value) => {
        if(value.name == "") value.name = "(unknown)"; 
        this.setAtributesOfBook(value);   
      })
      this.books = books;
    });
  }
  /**
   * Initializing the data of a given book, if a data is not initialized in the database it sets the value to ‘(unknown)’.
   * If the data is present in URL form, it converts it to the name associated with the URL.
   * 
   * @param value The book whose data we are initializing.
   */
  setAtributesOfBook(value: Book){
    if(value.isbn == '') value.isbn = '(unknown)';
    if(value.publisher == '') value.publisher = '(unknown)';
    if(value.country == '') value.country = '(unknown)';
    if(value.mediaType == '') value.mediaType = '(unknown)';
    if(value.released == '') value.released='(unknown)';
    if(value.authors[0]=='') value.authors[0]='(unknown)';

    if(value.characters.length == 0) value.characters[0]='(unknown)';
    else{
      value.characters.forEach((url: string, index: number)=>{
        this.charactersService.getCharacterByUrl(url).subscribe((character)=>{
          value.characters[index] = character.name;
          this.characterList[index] = character.name;
        });
      });
    }
   
  }
  /**
   * Searching for a specific book from the list.
   * 
   * @param name The name of the book we would like to search for.
   */
  searchBookByName(name: string){
    if (name == '') {
      this.error=false;
      localStorage.setItem(this.LOAD_BOOK_NAME, '');
      this.elementRouter.navigate(['books']);
    }else{
      this.booksService.getBookByName(name).subscribe((books)=>{
          this.error=false;
        if(books.length > 0){
          books.forEach((value) => {
            if(value.name == '') value.name = "(unknown)"; 
            this.setAtributesOfBook(value);   
          })
          localStorage.setItem(this.LOAD_BOOK_NAME,name);
          this.elementRouter.navigate(['books', name]);
          this.books = books;
          this.searchTerm = name;
        }else
            this.error = true; 
      });
    }
  }
  /**
   * Loading the data of a book with a given name.
   * @param name The name of the book we would like to load.
   */
  loadBookByName(name: string){
    this.booksService.getBookByName(name).subscribe((books)=>{
     books.forEach((value) => {
        if(value.name == "") value.name = "(unknown)"; 
        this.setAtributesOfBook(value);   
      })
      this.books = books;
      this.searchTerm = name;
    });
  }

  /**
   * Navigating to the route of the character with the given name.
   * @param character Name of character.
   */
  clickOnCharacter(character: string){
    this.elementRouter.navigate(['characters', character]);
  }


  /**
   * Searching for a character with a given name from the list of characters in the given book.
   * 
   * @param name Search character term
   * @param book The book from which you can search.
   */
  searchInList(name: string, book: Book){
    if(name){
      this.characterList = [];
      book.characters.forEach((character)=>{
        if(character.toLowerCase().includes(name.toLowerCase()))
          this.characterList.push(character);
        if(character.toLowerCase() == name.toLowerCase()){
          this.characterList = [];
          this.characterList.push(character);
        }
      })
    }else{
      this.characterList = book.characters;
    }
  }
}
