package hf.data

import android.graphics.Bitmap
import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import kotlinx.parcelize.Parcelize


@Entity(tableName = "image")
@TypeConverters(Converter::class)
@Parcelize
data class Image(
    @ColumnInfo(name = "id") @PrimaryKey(autoGenerate = true) var id: Long? = null,
    @ColumnInfo(name = "source") var source: Bitmap,
    @ColumnInfo(name = "edited") var edited: Bitmap,
    @ColumnInfo(name = "brightness") var brightness: Int,
    @ColumnInfo(name = "contrast") var contrast: Int,
    @ColumnInfo(name = "blurring") var blurring: Int,
    @ColumnInfo(name = "sharpening") var sharpening: Int,
    @ColumnInfo(name = "sepia") var pencilSketch: Int,
    @ColumnInfo(name = "grey") var grey: Int,
) : Parcelable

