package hf.data

import androidx.room.*

@Dao
interface ImageDao {
    @Query("SELECT * FROM image ORDER BY id DESC")
    fun getAll(): List<Image>

    @Insert
    fun insert(image: Image): Long

    @Update
    fun update(image: Image)

    @Delete
    fun deleteItem(image: Image)
}