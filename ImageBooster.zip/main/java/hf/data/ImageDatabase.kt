package hf.data

import android.content.ClipData
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(entities = [Image::class], version = 1)
abstract class ImageDatabase : RoomDatabase() {
    abstract fun imageDao(): ImageDao

    companion object {
        fun getDatabase(applicationContext: Context): ImageDatabase {
            return Room.databaseBuilder(
                applicationContext,
                ImageDatabase::class.java,
                "image-list5"
            ).build();
        }
    }
}