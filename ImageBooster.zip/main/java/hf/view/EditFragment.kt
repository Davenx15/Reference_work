package hf.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import hf.data.Image
import hf.data.ImageDatabase
import hf.main.R
import hf.main.databinding.FragmentEditBinding
import hf.view.adapter.ImageEffektAdapter
import kotlin.concurrent.thread


class EditFragment : Fragment(){
    private val args: EditFragmentArgs by navArgs()
    lateinit var binding: FragmentEditBinding
    lateinit var database: ImageDatabase
    lateinit var imageEdit: Image
    lateinit var maker: ImageEffektAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        database = ImageDatabase.getDatabase(this.requireContext())
        binding = FragmentEditBinding.inflate(inflater, container, false)
        maker = ImageEffektAdapter()
        imageEdit=args.image
        binding.imageView2.setImageBitmap(imageEdit.edited)
        binding.greySeekBar.max = 1

        setUpSeekBar(binding.bluringSeekBar, imageEdit.blurring, binding.blurring)
        setUpSeekBar(binding.brightnessSeekBar, imageEdit.brightness, binding.brightness)
        setUpSeekBar(binding.contrastSeekBar, imageEdit.contrast, binding.contrast)
        setUpSeekBar(binding.greySeekBar, imageEdit.grey, binding.grey)
        setUpSeekBar(binding.sharpeningSeekBar, imageEdit.sharpening, binding.sharpening)
        setUpSeekBar(binding.pencilSketchSeekBar, imageEdit.pencilSketch, binding.pencilSketch)

        binding.btnDecline.setOnClickListener(){
            findNavController().popBackStack()
        }

        binding.btnSave.setOnClickListener(){
            thread {
                database.imageDao().update(imageEdit)
                this.activity?.runOnUiThread {
                    findNavController().popBackStack()
                }
            }

        }
        return binding.root
    }

    private fun setUpSeekBar(seekBar: SeekBar, value: Int, attribute: TextView) {

        seekBar.progress = value
        seekBar.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                // Log the progress
                //Log.d("DEBUG", "Progress is: "+progress);

                when (attribute.id) {
                    R.id.blurring ->{
                        attribute.text = "Blurring: ${progress}"
                        imageEdit.blurring = progress
                    }
                    R.id.brightness ->{
                        attribute.text = "Brightness: ${progress}"
                        imageEdit.brightness = progress
                    }
                    R.id.contrast ->{
                        attribute.text = "Contrast: ${progress}"
                        imageEdit.contrast = progress
                    }
                    R.id.grey ->{
                        attribute.text = "Grey: ${progress}"
                        imageEdit.grey = progress
                    }
                    R.id.pencilSketch ->{
                        attribute.text = "Pencil Sketch: ${progress}"
                        imageEdit.pencilSketch = progress
                    }
                    R.id.sharpening ->{
                        attribute.text = "Sharpening: ${progress}"
                        imageEdit.sharpening = progress
                    }
                }

                imageEdit.edited = maker.changeAll(imageEdit.source, imageEdit.brightness,
                imageEdit.contrast, imageEdit.blurring, imageEdit.sharpening, imageEdit.pencilSketch, imageEdit.grey)
                binding.imageView2.setImageBitmap(imageEdit.edited)
            }

            override fun onStartTrackingTouch(p0: SeekBar?) {

            }

            override fun onStopTrackingTouch(p0: SeekBar?) {
            }

        })

        when (attribute.id) {
            R.id.blurring ->{
                attribute.text = "Blurring: ${value}"
            }
            R.id.brightness ->{
                attribute.text = "Brightness: ${value}"
            }
            R.id.contrast ->{
                attribute.text = "Contrast: ${value}"
            }
            R.id.grey ->{
                attribute.text = "Grey: ${value}"
            }
            R.id.pencilSketch ->{
                attribute.text = "Pencil Sketch: ${value}"
            }
            R.id.sharpening ->{
                attribute.text = "Sharpening: ${value}"
            }
        }
    }

}