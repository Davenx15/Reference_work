package hf.view.adapter

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.RequiresApi
import androidx.navigation.Navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import hf.data.Image
import hf.main.R
import hf.main.databinding.ImageListBinding
import java.util.*


class ImageAdapter(private val listener: ImageClickListener) :
    RecyclerView.Adapter<ImageAdapter.ImageViewHolder>() {

    private val images = mutableListOf<Image>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ImageViewHolder(
       ImageListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
    )


    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        val image = images[position]
        holder.binding.imageView.setImageBitmap(image.edited) //ideraktam editet
        holder.binding.brightness.text = "Brightness: ${ image.brightness}"
        holder.binding.contrast.text = "Contrast: ${image.contrast}"
        holder.binding.bluring.text = "Bluring: ${image.blurring}"
        holder.binding.sharpening.text = "Sharpening ${image.sharpening}"
        holder.binding.pencilSketch.text = "Pencil Sketch: ${image.pencilSketch}"
        holder.binding.grey.text = "Grey: ${image.grey}"
        holder.binding.btnDelete.setOnClickListener{
            listener.removeImage(image)
        }
        holder.itemView.setOnClickListener{
            listener.selectedImage(image)
        }

    }


    override fun getItemCount(): Int = images.size

    interface ImageClickListener {
        fun onItemChanged(item: Image)
        fun removeImage(item : Image)
        fun selectedImage(item : Image)
    }

    fun update(items: List<Image>) {
        images.clear()
        images.addAll(items)
        notifyDataSetChanged()
    }

    fun removeImage(item: Image){
        val pos = images.indexOf(item)
        images.remove(item)
        notifyItemRemoved(pos)
    }


    @RequiresApi(Build.VERSION_CODES.O)
    fun convertStringToBitmap(string: String): Bitmap? {
        try {
            val image = Base64.getDecoder().decode(string)
            return BitmapFactory.decodeByteArray(image, 0, image.size)
        }catch (ex: IllegalArgumentException){return null}
    }



    inner class ImageViewHolder(val binding: ImageListBinding) : RecyclerView.ViewHolder(binding.root)
}