package hf.view.adapter

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.nio.ByteBuffer


class ImageEffektAdapter() {

    fun makeGray(bitmap: Bitmap, scale: Int) : Bitmap {
        if(scale == 0) return bitmap
        else {
            // Create OpenCV mat object and copy content from bitmap
            val mat = Mat()
            Utils.bitmapToMat(bitmap, mat)

            // Convert to grayscale
            Imgproc.cvtColor(mat, mat, Imgproc.COLOR_RGB2GRAY)
            //Canny Edge transform
            //Imgproc.Canny(mat, mat, 50.0, 50.0)
            // Make a mutable bitmap to copy grayscale image
            val grayBitmap = bitmap.copy(bitmap.config, true)
            Utils.matToBitmap(mat, grayBitmap)

            return grayBitmap
        }
    }



    fun changeSketch(bmp: Bitmap, progress: Int): Bitmap{
        if (progress==0 ) return bmp
        // NewValue = (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
        var joErtek: Double = (((progress - 0.0) * (250.0 - 20.0)) / (100.0 - 0.0)) + 20.0
        val src : Mat = Mat(bmp.getHeight(),bmp.getWidth(), CvType.CV_32SC1)
        Utils.bitmapToMat(bmp,src);

        val grey_img: Mat = Mat(src.rows(), src.cols(), src.type())
        Imgproc.cvtColor(src,grey_img, Imgproc.COLOR_RGB2GRAY)
        val invert_Image : Mat = Mat(grey_img.rows(), grey_img.cols(), grey_img.type())
        Core.bitwise_not(grey_img, invert_Image);
        val blur_img :Mat = Mat(invert_Image.rows(), invert_Image.cols(), invert_Image.type())
        Imgproc.GaussianBlur(invert_Image, blur_img, Size(111.0,111.0), 0.0)
        val invblur: Mat = Mat(blur_img.rows(), blur_img.cols(), blur_img.type())
        Core.bitwise_not(blur_img, invblur)

        val res : Mat = Mat(src.rows(), src.cols(), src.type())
        Core.divide(grey_img, invblur, res, joErtek)
        val result = Bitmap.createBitmap(res.cols(),res.rows(), Bitmap.Config.ARGB_8888);
        Utils.matToBitmap(res, result);


        return result
    }

    fun changeSharpenes(bmp: Bitmap, progress: Int): Bitmap {
        if (progress==0 ) return bmp
        // NewValue = (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
        val joErtek : Double = (((progress - 0) * (5 - 1)) / (100 - 0)) + 1.0
        val src : Mat = Mat(bmp.getHeight(),bmp.getWidth(), CvType.CV_32SC1)
        Utils.bitmapToMat(bmp,src);
        Imgproc.GaussianBlur(src, src, Size(0.0,0.0), joErtek)
        val dest : Mat = Mat(src.rows(), src.cols(), src.type())
        Core.addWeighted(src, 1.5, dest, -0.5, 0.0, dest);
        val result = Bitmap.createBitmap(dest.cols(),dest.rows(), Bitmap.Config.ARGB_8888);
        Utils.matToBitmap(dest, result);
        return result
    }

    fun changeSharpeness2(bmp: Bitmap, percentage:Int):Bitmap{

        val src : Mat = Mat(bmp.getHeight(),bmp.getWidth(), CvType.CV_32SC1)
        Utils.bitmapToMat(bmp,src);
        //hogyan kell letrehozni
        val buffer : ByteBuffer = ByteBuffer.allocate(9)
        buffer.put(-1);
        buffer.put(-1);
        buffer.put(-1);
        buffer.put(-1);
        buffer.put(9);
        buffer.put(-1);
        buffer.put(-1);
        buffer.put(-1);
        buffer.put(-1);


        val kernel = Mat(3, 3, src.type(), buffer)


//        [-1,-1,-1]
//        [-1, 9,-1]
//        [-1,-1,-1]


        Imgproc.filter2D(src, src ,-1, kernel)

        val result = Bitmap.createBitmap(src.cols(),src.rows(), Bitmap.Config.ARGB_8888);
        Utils.matToBitmap(src, result);
        return result
    }


    fun changeBluring(bmp: Bitmap, progress: Int): Bitmap{
        if (progress==0 ) return bmp
        val src : Mat = Mat(bmp.getHeight(),bmp.getWidth(), CvType.CV_32SC1)
        Utils.bitmapToMat(bmp,src);

        if (progress % 2 == 1) {
            Imgproc.GaussianBlur(src, src, Size(progress.toDouble(), progress.toDouble()), 0.0, 0.0)
            val result = Bitmap.createBitmap(src.cols(),src.rows(), Bitmap.Config.ARGB_8888);
            Utils.matToBitmap(src,result);
            return result
        }else{
            Imgproc.GaussianBlur(src, src, Size(progress.toDouble()-1, progress.toDouble()-1), 0.0, 0.0)
            val result = Bitmap.createBitmap(src.cols(),src.rows(), Bitmap.Config.ARGB_8888);
            Utils.matToBitmap(src,result);
            return result
        }
    }

    // f(i,j)= alpha*k(i,j)+beta
    fun changeContrastBrightnesss(bmp: Bitmap, alpha: Int, beta: Int): Bitmap{
        if (alpha==0 && beta==0) return bmp

        // NewValue = (((OldValue - OldMin) * (NewMax - NewMin)) / (OldMax - OldMin)) + NewMin
        // alpha:Contrast[1..3] beta:Brightness[0..100]
        val joAlpha: Double = (((alpha - 0) * (3.0 - 1.0)) / (100 - 0)) + 1


        val src : Mat = Mat(bmp.getHeight(),bmp.getWidth(), CvType.CV_32SC1)
        Utils.bitmapToMat(bmp,src);
        src.convertTo(src, -1, joAlpha , beta.toDouble())

        val result = Bitmap.createBitmap(src.cols(),src.rows(), Bitmap.Config.ARGB_8888);
        Utils.matToBitmap(src,result);
        return result;
    }



    fun changeAll(btm: Bitmap, brght: Int, contrast: Int ,blurring: Int, sharp:Int, pencil: Int, grey: Int ): Bitmap{

        var res =changeContrastBrightnesss(btm, contrast, brght)
        res=changeBluring(res, blurring)
        res=changeSharpenes(res,sharp)
        res=changeSketch(res, pencil)
        res=makeGray(res, grey)

        return res
    }




}