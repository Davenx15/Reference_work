package hf.view


import android.opengl.Visibility
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import hf.data.Image
import hf.data.ImageDatabase
import hf.main.databinding.FragmentGalleryBinding
import hf.view.adapter.ImageAdapter
import kotlin.concurrent.thread

class GalleryFragment : Fragment(), ImageAdapter.ImageClickListener {
    private lateinit var binding: FragmentGalleryBinding
    private lateinit var adapter: ImageAdapter
    private lateinit var database: ImageDatabase

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = FragmentGalleryBinding.inflate(inflater, container, false)
        database = context?.let { ImageDatabase.getDatabase(it) }!!
        initRecyclerView()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

    private fun initRecyclerView() {
        adapter = ImageAdapter(this)
        binding.imageRecylcerView.layoutManager = LinearLayoutManager(this.context)
        binding.imageRecylcerView.adapter = adapter
        loadItemsInBackground()
    }

    private fun loadItemsInBackground() {
        thread {
            val images = database.imageDao().getAll()
            this.activity?.runOnUiThread {
                if (images.size > 0) {
                    binding.noPicture.visibility = TextView.GONE
                }
                    adapter.update(images)

            }
        }
    }

    override fun onItemChanged(item: Image) {
        thread {
            database.imageDao().update(item)
        }
    }

    override fun removeImage(item: Image) {
        thread {
            database.imageDao().deleteItem(item)
        }
        adapter.removeImage(item)
        if(adapter.itemCount == 0){
            binding.noPicture.visibility = TextView.VISIBLE
        }
    }

    override fun selectedImage(item: Image) {
        val action = GalleryFragmentDirections.actionGalleryFragmentToEditFragment(item)
        findNavController().navigate(action)
    }

}