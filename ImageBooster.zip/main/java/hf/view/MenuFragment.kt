package hf.view

import android.app.Activity.RESULT_OK
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import hf.data.Image
import hf.data.ImageDatabase
import hf.main.R
import hf.main.databinding.FragmentMenuBinding
import hf.view.adapter.ImageAdapter
import kotlin.concurrent.thread

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class MenuFragment : Fragment(){
    val REQUEST_IMAGE_CAPTURE = 1
    private lateinit var binding : FragmentMenuBinding
    private lateinit var database: ImageDatabase

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding = FragmentMenuBinding.inflate(inflater, container, false)
        database = context?.let { ImageDatabase.getDatabase(it) }!!
        return binding.root;
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.gallery.setOnClickListener {
            findNavController().navigate(R.id.action_menuFragment_to_galleryFragment)
        }
        binding.photo.setOnClickListener {
            val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            try {
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
            } catch (e: ActivityNotFoundException) {
                // display error state to the user
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap

            Toast.makeText(this.context, "Kép elmentve", Toast.LENGTH_LONG).show()
            val image = Image(source = imageBitmap,
                edited = imageBitmap,
                brightness = 0,
                contrast = 0,
                blurring = 0,
                sharpening = 0,
                pencilSketch = 0,
                grey = 0)
            insertImage(image)
        }
    }

    fun insertImage(image: Image){
        thread{
            database.imageDao().insert(image)
        }
    }


}