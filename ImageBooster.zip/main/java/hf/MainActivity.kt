package hf

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import hf.main.R
import org.opencv.android.OpenCVLoader

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        OpenCVLoader.initDebug()
        setTheme(R.style.Theme_ImageBooster)
        setContentView(R.layout.activity_main)

    }
}